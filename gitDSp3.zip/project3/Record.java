package project3;
/**
 * This class, which implements Comparable<Record>, represents the Record object which contains 
 * three variables: name(Name), business(String), and location(Location).
 * It contains a constructor, as well as getters and setters, an equals method (overridden), 
 * a compareTo method (overridden), and a toString method (overridden)
 * @author Katherine Han
 * @version 03/16/2023
 */
public class Record implements Comparable<Record>{
	private Name name;
	private String business;
	private Location location;
	//Record constructor throws IAE when the name or location variables are empty or null
	/**
	 * Record constructor with name, business, and location parameters
	 * @param name a Name object
	 * @param business a business String
	 * @param location a Location object
	 * @throws IllegalArgumentException if the name or location parameter is blank or null
	 */
	public Record(Name name, String business, Location location)
	{
		if(name == null || name.equals(""))
		{
			throw new IllegalArgumentException("Entered a null or blank name object");
		}
		else
		{
			this.name = name;
		}
		if(business == null) //if the business string is null, set it to an empty string to avoid null errors
		{
			business = "";
		}
		else
		{
			this.business = business;
		}
		if(location == null || location.equals(""))
		{
			throw new IllegalArgumentException("Entered a null or blank location object");
		}
		else
		{
			this.location = location;
		}
	}
	//getters and setters for the name, business, and location variables
	public Name getName() {
		return name;
	}

	public void setName(Name name) {
		this.name = name;
	}

	public String getBusiness() {
		return business;
	}

	public void setBusiness(String business) {
		this.business = business;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}
	/**
	 * Checks if the parameter Object is equal to the specified Record object
	 * @param Object E to be compared with the specified Record object
	 * @return true if the parameter Object and the Record object's name, business, 
	 * and location are equal (case insensitive), false if they aren't equal
	 */
	@Override
	public boolean equals(Object E) 
	{
		if(E == this) //returns true if the parameter and the specified Record object are the same
		{
			return true;
		}
		if(!(E instanceof Record)) //if the object is not of the Record class, return false
		{
			return false;
		}
		Record newE = (Record) E; //cast the Object E to Record
		if(this.name.equals(newE.getName()))
		{
			if(this.business.equalsIgnoreCase(newE.getBusiness()))
			{
				if(this.location.equals(newE.getLocation()))
				{
					return true; //if the name, business, and location are all equal (case insensitive), return true
				}
			}
		}
		return false; //if true was not returned, return false as they are not equal
	}
	/**
	 * Compares parameter Record E and the specified Record object, returns an integer 
	 * that indicates which is first lexicographically
	 * @param Record E to be compared with the specified Record object
	 * @return -1 or 0 or 1 based on whether the specified Record object's variables are before, equal to, 
	 * or after the parameter Record E's variables (alphabetical)
	 */
	@Override
	public int compareTo(Record E)
	{
		if(E.getName().compareTo(this.name) == 0) //compares both name variables
		{
			if(E.getLocation().compareTo(this.location) == 0) /*if the Record parameter name variable and specified 
				Record object name variable are equal, compare the location variables*/
			{
				return 0; //if both name and location variables are equal, return zero
			}
			else
			{
				if(E.getLocation().compareTo(this.location) < 0) /*compare the variables if they don't equate to zero 
				with the compareTo function, return a value below or above 0 depending on which is farther lexicographically*/
				{
					return 1;
				}
				else
				{
					return -1;
				}
			}
		}
		else
		{
			if(E.getName().compareTo(this.name) < 0)
			{
				return 1;
			}
			else
			{
				return -1;
			}
		}
	}
	/**
	 * Creates a String that prints the last name, first name, middle initial, business, city, state, country, 
	 * and zip code separated by a comma and space
	 * @return a two line String that contains all the variables of the Record object
	 */
	@Override
	public String toString() /*toString produces the last name, first name, and middle initial and then on an 
	indented new line produces the business, city, state, country, and zip code (everything separated by a comma and space)*/
	{
		return this.getName().getlName() + ", " + this.getName().getfName() + ", " + this.getName().getmInit() + 
			"\n\t" + this.getBusiness() + ", " + this.getLocation().getCity() + ", " + this.getLocation().getState() + ", " +
			this.getLocation().getCountry() + ", " + this.getLocation().getZip();
	}
}
