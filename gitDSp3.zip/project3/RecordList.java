package project3;
import java.util.*;
/**
 * This class, which extends ArrayList<Record>, represents a RecordList list that contains Record objects
 * It contains a default constructor, as well as a getByName method, getByCity method, getByZip method, 
 * and a toString method (overridden)
 * The getByName, getByCity, and getByZip methods all represent specific search methods that 
 * have keyword parameters
 * @author Katherine Han
 * @version 03/16/2023
 */
public class RecordList extends ArrayList<Record>{
	public RecordList(){} //default constructor
	/**
	 * Searches Record objects and checks if the first or last name contains the keyword parameter
	 * If so, the Record object is added to the RecordList created
	 * @param keyword a keyword String that the Record object's first or last name may contain
	 * @throws IllegalArgumentException if the keyword parameter is blank or null
	 * @return a RecordList that is either empty or contains the Record objects that have a first or 
	 * last name that contains the keyword
	 */
	public RecordList getByName(String keyword)
	{
		RecordList listByName = new RecordList(); //creates new RecordList list
		if(keyword == null || keyword.equals("")) //if the keyword String parameter is null or blank, throw an IAE
		{
			throw new IllegalArgumentException("Entered an empty/null keyword");
		}
		String newKey = keyword.toLowerCase(); //sets the keyword to lowercase to compare case insensitively
		for(Record E: this) //traverse the list of Record objects
		{
			//checks if the first or last name contains the keyword parameter
			if(E.getName().getlName().toLowerCase().contains(newKey) || E.getName().getfName().toLowerCase().contains(newKey)) 
			{
				//if the first or last name contains the String keyword, add this Record object to the Recordlist list
				listByName.add(E); 
			}
		}
		if(listByName.size() == 0) //if no Record objects were added to the list, return null as there are no matches
		{
			return null;
		}
		return listByName; //if null was not returned, return the list that contains the Record objects
	}
	/**
	 * Searches Record objects and checks if the city contains the keyword parameter
	 * If so, the Record object is added to the RecordList created
	 * @param keyword a keyword String that the Record object's city may contain
	 * @throws IllegalArgumentException if the keyword parameter is blank or null
	 * @return a RecordList that is either empty or contains the Record objects that 
	 * have a city that contains the keyword
	 */
	public RecordList getByCity (String keyword)
	{
		RecordList listByCity = new RecordList();
		if(keyword == null || keyword.equals(""))
		{
			throw new IllegalArgumentException("Entered an empty/null keyword");
		}
		String newKey = keyword.toLowerCase();
		for(Record E: this)
		{
			//checks if the city contains the keyword, if true, add this Record object to the list
			if(E.getLocation().getCity().toLowerCase().contains(newKey)) 
			{
				listByCity.add(E);
			}
		}
		if(listByCity.size() == 0)
		{
			return null;
		}
		return listByCity;
	}
	/**
	 * Searches Record objects and checks if the zip String contains the zip parameter
	 * If so, the Record object is added to the RecordList created
	 * @param zip a zip String that the Record object's zip code may contain
	 * @throws IllegalArgumentException if the zip parameter is blank or null
	 * @return a RecordList that is either empty or contains the Record objects that have 
	 * a zip String that contains the parameter zip
	 */
	public RecordList getByZip(String zip)
	{
		RecordList listByZip = new RecordList();
		if(zip == null || zip.length() != 5) /*checks if the zip is null or if the length is not 5 digits, 
		if either is true, throw IAE*/
		{
			throw new IllegalArgumentException("Entered a null zip code or a zip code that is not 5 digits");
		}
		for(int i = 0; i < zip.length(); i++) /*checks each zip character to check if it is a valid number 
		character (0-9), throws IAE if it contains invalid characters*/
		{
			if(zip.charAt(i) < '0' || zip.charAt(i) > '9')
			{
				throw new IllegalArgumentException("Entered a invalid number for zip code. Only enter 0-9 as a number");
			}
		}
		for(Record E: this)
		{
			if(E.getLocation().getZip().contains(zip)) /*checks if the zip contains the String zip parameter, 
			if true, add this Record object to the list*/
			{
				listByZip.add(E);
			}
		}
		if(listByZip.size() == 0)
		{
			return null;
		}
		return listByZip;
	}
	/**
	 * Creates a String that contains the Record object toStrings that have matches with the 
	 * method called in separate lines
	 * @return a String that has the added Record object's toStrings in separate lines
	 */
	@Override
	//this toString produces a string that prints out each Record object on separate lines
	public String toString() 
	{
		String returnString = new String("");
		int counter = 0;
		for(Record E : this)
		{
			if(counter == this.size()) //if this is the last Record object, don't add a new line after
			{
				returnString += E.toString();
			}
			else
			{
				returnString += E.toString() + "\n";
			}
		}
		return returnString; //return the string with all the Record object toStrings
	}
}
