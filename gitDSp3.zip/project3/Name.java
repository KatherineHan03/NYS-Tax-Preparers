package project3;
/**
 * This class, which implements Comparable<Name>, represents the Name object which contains 
 * three variables: last name(String), first name(String), middle initial (char).
 * It contains three constructors, as well as getters and setters, an equals method (overridden), 
 * and a compareTo method (overridden) 
 * @author Katherine Han
 * @version 03/16/2023
 */
public class Name implements Comparable<Name>{ 
	private String lName;
	private String fName;
	private char mInit;
	//All Name constructors throw IAE when the last name is an empty string or null
	/**
	 * Name constructor with lName parameter
	 * @param lName a String last name
	 * @throws IllegalArgumentException if the lName parameter is null or blank
	 */
	public Name(String lName) throws IllegalArgumentException
	{
		if(lName == null || lName.equals(""))
		{
			throw new IllegalArgumentException("Entered a null or blank last name");
		}
		else
		{
			this.lName = lName;
		}
	}
	/**
	 * Name constructor with lName and fName parameter
	 * @param lName a String last name
	 * @param fName a String first name
	 * @throws IllegalArgumentException if the lName parameter is null or blank
	 */
	public Name(String lName, String fName) throws IllegalArgumentException 
	{
		if(lName == null || lName.equals(""))
		{
			throw new IllegalArgumentException("Entered a null or blank last name");
		}
		else
		{
			this.lName = lName;
		}
		if(fName == null)
		{
			this.fName = ""; //sets the first name to a blank string if it is null to avoid errors
		}
		else
		{
			this.fName = fName;
		}
	}
	/**
	 * Name constructor with lName, fName, and mInit parameter
	 * @param lName a String last name
	 * @param fName a String first name
	 * @param mInit a char middle initial
	 * @throws IllegalArgumentException if the lName parameter is null or blank
	 */
	public Name(String lName, String fName, char mInit) throws IllegalArgumentException
	{
		if(lName == null || lName.equals(""))
		{
			throw new IllegalArgumentException("Entered a null or blank last name");
		}
		else
		{
			this.lName = lName;
		}
		if(fName == null)
		{
			this.fName = "";
		}
		else
		{
			this.fName = fName;
		}
		if(mInit == 0)
		{
			this.mInit = ' '; //sets the middle initial to a blank character if it is null to avoid errors
		}
		else
		{
			this.mInit = mInit;
		}
	}
	//getters and setters for the first and last name and middle initial variables
	public String getlName() { 
		return lName;
	}

	public void setlName(String lName) {
		this.lName = lName;
	}

	public String getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName = fName;
	}

	public char getmInit() {
		return mInit;
	}

	public void setmInit(char mInit) {
		this.mInit = mInit;
	}
	/**
	 * Checks if the parameter Object is equal to the specified Name object
	 * @param Object E to be compared with the specified Name object
	 * @return true if the parameter Object and the Name object's last name, first name, 
	 * and middle initial are equal (case insensitive), false if they aren't equal
	 */
	@Override
	public boolean equals(Object E) 
	{
		if(E == this)
		{
			return true; //returns true if the parameter and the specified Name object are the same
		}
		if(!(E instanceof Name)) //if the object is not of the Name class, return false
		{
			return false;
		}
		Name newE = (Name) E; //cast the Object E to Name
		if(this.lName.equalsIgnoreCase(newE.getlName()))
		{
			if(this.fName.equalsIgnoreCase(newE.getfName()))
			{
				if(Character.isUpperCase(this.mInit) == Character.isUpperCase(newE.getmInit()))
				{
					return true; /*if the last name, first name, and middle initial are all equal 
					(case insensitive), return true*/
				}
			}
		}
		return false; //if true was not returned, return false as they are not equal
	}
	/**
	 * Compares parameter Name E and the specified Name object, returns an integer that indicates which 
	 * is first lexicographically
	 * @param Name E to be compared with the specified Name object
	 * @return -1 or 0 or 1 based on whether the specified Name object's variables are before, equal to, 
	 * or after the parameter Name E's variables (alphabetical)
	 */
	@Override
	public int compareTo(Name E)
	{
		/*sets the middle initials for the parameter Name E and the specified Name object to uppercase, 
		which allows for case insensitive comparison*/
		char thismInit = Character.toUpperCase(this.mInit); 
		char EmInit = Character.toUpperCase(E.getmInit());
		
		if(E.getlName().compareToIgnoreCase(this.lName) == 0) //compares last name
		{
			if(E.getfName().compareToIgnoreCase(this.fName) == 0) //if last names are the same, compare first names
			{
				if(Character.compare(EmInit, thismInit) == 0) /*if first and last names are the same, 
				compare the middle initials*/
				{
					return 0;
				}
				/*return a value less or greater than 0 based on whether the parameter name or specified name 
				 * is farther lexicographically*/
				else if(Character.compare(EmInit, thismInit) < 0) 
				{
					return 1;
				}
				else
				{
					return -1;
				}
			}
			else
			{
				if(E.getfName().compareToIgnoreCase(this.fName) < 0)
				{
					return 1;
				}
				else
				{
					return -1;
				}	
			}
		}
		
		else if(E.getlName().compareToIgnoreCase(this.lName) < 0)
		{
			return 1;
		}
		else
		{
			return -1;
		}
	}
}
