package project3;
/**
 * This class, which implements Comparable<Location>, represents the Location object 
 * which contains four variables: city(String), state(String), country(char), and zip(String).
 * It contains a constructor, as well as getters and setters, an equals method (overridden), 
 * and a compareTo method (overridden) 
 * @author Katherine Han
 * @version 03/16/2023
 */
public class Location implements Comparable<Location>{
	private String city;
	private String state;
	private String country;
	private String zip;
	//Location constructor throws IAE when the city is an empty string or null
	/**
	 * Location constructor with city, state, country, and zip parameters
	 * @param city a String city
	 * @param state a String state
	 * @param country a String country
	 * @param zip a String zip code
	 * @throws IllegalArgumentException if the city parameter is null or blank
	 * @throws IllegalArgumentException if the zip parameter is greater than 5 digits 
	 * or contains invalid characters (not 0-9)
	 */
	public Location ( String city, String state, String country, String zip ) throws IllegalArgumentException
	{
		if(city == null || city.equals(""))
		{
			throw new IllegalArgumentException("Entered a null or blank city");
		}
		this.city = city;	
		if(state == null)
		{
			this.state = ""; //sets the state to a blank string if it is null to avoid errors
		}
		else
		{
			this.state = state;
		}
		if(country == null)
		{
			this.country = ""; //sets the country to a blank string if it is null to avoid errors
		}
		else
		{
			this.country = country;
		}
		for(int i = 0; i < zip.length(); i++) /*checks each character in the zip code to ensure that 
		it only contains valid characters (0-9)*/
		{
			if(zip.charAt(i) < '0' || zip.charAt(i) > '9')
			{
				throw new IllegalArgumentException("Entered a invalid number for zip code. Only enter 0-9 as a number");
			}
		}
		if(zip.length() > 5) //throws IAE if the zip code is greater than 5 digits
		{
			throw new IllegalArgumentException("Entered a zip code over 5 digits");
		}
		if(zip == null)
		{
			this.zip = ""; //sets the zip code to a blank string if it is null to avoid errors
		}
		String newZip = "";
		if(zip.length() < 5) /*if the zip code is less than 5 digits, a zero is added to the beginning of the zip 
		code until it is 5 digits*/
		{
			newZip = zip;
			for(int i = 0; i < (5 - zip.length()); i++)
			{
				newZip = "0" + newZip; //concatenates the zip code and the 0's
			}
			this.zip = newZip; //sets the zip code to this new zip code with 5 digits
		}
		else
		{
			this.zip = zip;
		}
	}
	//getters and setters for the city, state, country, and zip variables
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}
	/**
	 * Checks if the parameter Object is equal to the specified Location object
	 * @param Object E to be compared with the specified Location object
	 * @return true if the parameter Object and the Location object's city, state, country, 
	 * and zip are equal (case insensitive), false if they aren't equal
	 */
	@Override
	 public boolean equals(Object E) 
	{
		if(E == this) //returns true if the parameter and the specified Name object are the same
		{
			return true;
		}
		if(!(E instanceof Location)) //if the object is not of the Location class, return false
		{
			return false;
		}
		Location newE = (Location) E; //cast the Object E to Location
		if(this.city.equalsIgnoreCase(newE.getCity()))
		{
			if(this.state.equalsIgnoreCase(newE.getState()))
			{
				if(this.country.equalsIgnoreCase(newE.getCountry()))
				{
					if(this.zip.equalsIgnoreCase(newE.getZip()))
					{
						return true; /*if the city, state, country, and zip code are all equal 
						(case insensitive), return true*/
					}
				}
			}		
		}
		return false; //if true was not returned, return false as they are not equal
	}
	/**
	 * Compares parameter Location E and the specified Location object, returns an integer that 
	 * indicates which is first lexicographically
	 * @param Location E to be compared with the specified Location object
	 * @return -1 or 0 or 1 based on whether the specified Location object's variables are before, 
	 * equal to, or after the parameter Location E's variables (alphabetical)
	 */
	@Override
	public int compareTo(Location E)
	{
		//sets the String zip variables to integers to compare them numerically
		int thisZip = Integer.parseInt(this.zip);
		int EZip = Integer.parseInt(E.getZip());
		if(EZip == thisZip) //compares zip codes
		{
			if(E.getCity().compareToIgnoreCase(this.city) == 0) /*if the zip codes are equal, 
			compare the cities alphabetically (case insensitive)*/
			{
				if(E.getState().compareToIgnoreCase(this.state) == 0) /*if the zip codes and the cities are the same, 
				compare the states alphabetically (case insensitive)*/
				{
					if(E.getCountry().compareToIgnoreCase(this.country) == 0) /*if the zip codes, the cities, 
					and the states are equal, compare the countries alphabetically (case insensitive)*/
					{
						return 0; //if all variables are equal, return 0 as the two Location objects are the same
					}
					else
					{
						if(E.getCountry().compareToIgnoreCase(this.country) < 0) /*if the variable is not equal, 
							return a value less than or greater than 0 depending on whether the Location parameter
							or the specified Location object is farther lexicographically*/
						{
							return 1;
						}
						else
						{
							return -1;
						}
					}
				}
				else
				{
					if(E.getState().compareToIgnoreCase(this.state) < 0)
					{
						return 1;
					}
					else
					{
						return -1;
					}
				}
			}
			else
			{
				if(E.getCity().compareToIgnoreCase(this.city) < 0)
				{
					return 1;
				}
				else
				{
					return -1;
				}
			}
		}
		else
		{
			if(thisZip > EZip)
			{
				return 1;
			}
			else
			{
				return -1;
			}
		}
	}
}
